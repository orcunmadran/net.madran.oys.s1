<html>
<head>
<title>Sanal Kamp�s - Ba�kent �niversitesi E�itim Fak�ltesi</title>
<meta http-equiv="content-language" content="TR">
<meta http-equiv="content-type" content="text/html; charset=windows-1254">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9">
<meta name="description" content="FW MX 2004 DW MX 2004 HTML">
<!--Fireworks MX 2004 Dreamweaver MX 2004 target.  Created Thu Jan 26 14:22:46 GMT+0200 (GTB Standard Time) 2006-->
<link href="../iys.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
body {
	background-color: #666666;
}
.style1 {color: #CC0000}
-->
</style></head>
<body>
<!--The following section is an HTML table which reassembles the sliced image in a browser.-->
<!--Copy the table section including the opening and closing table tags, and paste the data where-->
<!--you want the reassembled image to appear in the destination document. -->
<!--======================== BEGIN COPYING THE HTML HERE ==========================-->
<br>
<table width="640" border="0" align="center" cellpadding="0" cellspacing="0">
<!-- fwtable fwsrc="giris.png" fwbase="index.gif" fwstyle="Dreamweaver" fwdocid = "2077649383" fwnested="0" -->
  <tr>
<!-- Shim row, height 1. -->
   <td><img src="../fw_giris/spacer.gif" width="128" height="1" border="0" alt=""></td>
   <td><img src="../fw_giris/spacer.gif" width="384" height="1" border="0" alt=""></td>
   <td><img src="../fw_giris/spacer.gif" width="128" height="1" border="0" alt=""></td>
   <td><img src="../fw_giris/spacer.gif" width="1" height="1" border="0" alt=""></td>
  </tr>

  <tr><!-- row 1 -->
   <td colspan="3"><img name="index_r1_c1" src="../fw_giris/index_r1_c1.gif" width="640" height="30" border="0" alt=""></td>
   <td><img src="../fw_giris/spacer.gif" width="1" height="30" border="0" alt=""></td>
  </tr>
  <tr><!-- row 2 -->
   <td colspan="3"><img name="index_r2_c1" src="../fw_giris/index_r2_c1.gif" width="640" height="66" border="0" alt=""></td>
   <td><img src="../fw_giris/spacer.gif" width="1" height="66" border="0" alt=""></td>
  </tr>
  <tr><!-- row 3 -->
   <td><img name="index_r3_c1" src="../fw_giris/index_r3_c1.gif" width="128" height="288" border="0" alt=""></td>
   <td bgcolor="#FFFFFF">     <p align="center" class="baslik style1">Yetkiniz Yok !!! </p>     <p align="center" class="arabaslik">Ula�mak istedi�iniz <br>
        sayfalar yetkiniz d���ndad�r.</p>     
     <p align="center" class="altbaslik">Sisteme geri d�nmek i�in <a href="javascript:history.back()">t�klay�n�z</a>. </p>
     <p align="center" class="altbaslik">Yeniden giri� 
    yapmak i�in <a href="index.php">t�klay�n�z</a>.</p></td>
   <td><img name="index_r3_c3" src="../fw_giris/index_r3_c3.gif" width="128" height="288" border="0" alt=""></td>
   <td><img src="../fw_giris/spacer.gif" width="1" height="288" border="0" alt=""></td>
  </tr>
  <tr><!-- row 4 -->
   <td colspan="3"><img name="index_r4_c1" src="../fw_giris/index_r4_c1.gif" width="640" height="96" border="0" alt=""></td>
   <td><img src="../fw_giris/spacer.gif" width="1" height="96" border="0" alt=""></td>
  </tr>
<!--   This table was automatically created with Macromedia Fireworks   -->
<!--   http://www.macromedia.com   -->
</table>
<!--========================= STOP COPYING THE HTML HERE =========================-->
<p align="center"><span class="copyright">&copy; 2006 - Bilgisayar ve ��retim Teknolojileri E�itimi B�l�m�</span></p>
</body>
</html>
