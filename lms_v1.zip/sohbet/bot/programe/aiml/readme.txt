These AIML files are provided so you can test Program E to make sure it is functional. Your bot will not be very smart with just these files loaded.

You can find more AIML sets that work well with Program E by going to http://sourceforge.net/project/showfiles.php?group_id=43190

No matter what AIML files you use you should use the startup.xml file provided here as your starting point for your own startup.xml.