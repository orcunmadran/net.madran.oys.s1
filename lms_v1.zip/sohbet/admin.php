<?php
@header('Location: admin/index.php');
?>