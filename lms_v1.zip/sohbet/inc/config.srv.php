<?php
	$GLOBALS['fc_config']['db'] = array(
		'host' => 'localhost',
		'user' => 'root',
		'pass' => '9360673',
		'base' => 'iys',
		'pref' => 'sohbet_',
	);
?>