<?php
			$this->sendToUser($userID, new Message('ngag', $this->userid, null, $txt));
?>