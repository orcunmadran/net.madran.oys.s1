<?php
			$this->sendToUser($userID, new Message('gag', $this->userid, null, $min));
?>