<?php
			$this->sendToUser($userID, new Message('alrt', $this->userid, null, $txt));
?>