<?php
			$this->sendToAll(new Message('calrt', $this->userid, null, $txt));
?>