<?php
	$GLOBALS['fc_config']['bot']->logout($userName);
?>