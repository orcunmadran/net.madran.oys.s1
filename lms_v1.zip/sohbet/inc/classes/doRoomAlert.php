<?php
			$this->sendToRoom($roomID, new Message('ralrt', $this->userid, null, $txt));
?>