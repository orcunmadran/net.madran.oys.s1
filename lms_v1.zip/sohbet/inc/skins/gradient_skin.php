<?php
	$GLOBALS['fc_config']['skin']['gradient_skin'] = array(
		'name' => 'Gradient',
		'swf_name' => 'gradient_skin'
	);
?>