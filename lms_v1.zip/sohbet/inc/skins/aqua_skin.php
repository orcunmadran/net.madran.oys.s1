<?php
	$GLOBALS['fc_config']['skin']['aqua_skin'] = array(
		'name' => 'Macintosh Aqua',
		'swf_name' => 'aqua_skin'
	);
?>