<?php
	$GLOBALS['fc_config']['skin']['default'] = array(
		'name' => 'Flash MX',
		'swf_name' => 'default_skin'
	);
?>