<?php
	$GLOBALS['fc_config']['skin']['xp_skin'] = array(
		'name' => 'Windows XP',
		'swf_name' => 'xp_skin'
	);
?>