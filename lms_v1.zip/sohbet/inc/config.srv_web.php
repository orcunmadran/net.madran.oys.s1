<?php
	$GLOBALS['fc_config']['db'] = array(
		'host' => 'localhost',
		'user' => 'skwebtr_root',
		'pass' => '9360673',
		'base' => 'skwebtr_vt',
		'pref' => 'sohbet_',
	);
?>