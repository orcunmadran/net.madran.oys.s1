<?php
	require_once('inc/common.php');
?>
<html>
	<body marginwidth="0" marginheight="0" leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" scroll="no" onLoad="showLogger()">
		<?php echo flashTag('logger', 'logger.swf')?>
	</body>
</html>