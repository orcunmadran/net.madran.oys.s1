<?php /* Smarty version 2.6.10, created on 2006-09-07 16:31:38
         compiled from bottom.tpl */ ?>

</body>
</html>